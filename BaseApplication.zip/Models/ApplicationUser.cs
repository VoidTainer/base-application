﻿using Microsoft.AspNetCore.Identity;

namespace BaseApplication.Models;

public class ApplicationUser : IdentityUser
{
    public string? FullName { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}